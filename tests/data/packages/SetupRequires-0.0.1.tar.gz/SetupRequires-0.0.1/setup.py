from setuptools import setup
import upper

setup(
    name='SetupRequires',
    version='0.0.1',
    packages=['setuprequires'],
)
