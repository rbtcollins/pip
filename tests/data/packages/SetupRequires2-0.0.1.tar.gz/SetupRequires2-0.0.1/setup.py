from setuptools import setup

setup(
    name='SetupRequires2',
    version='0.0.1',
    packages=['setuprequires2'],
)
